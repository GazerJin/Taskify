package com.mobdeve.s15.bautista.samantha.taskify.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.mobdeve.s15.bautista.samantha.taskify.R;
import com.mobdeve.s15.bautista.samantha.taskify.ViewDescription;
import com.mobdeve.s15.bautista.samantha.taskify.model.TaskModel;
import java.util.List;

public class TaskAdapter extends RecyclerView.Adapter<TaskViewHolder> {
    private List<TaskModel> data;
    private Context context;

    public TaskAdapter(Context context, List<TaskModel> taskList) {
        this.context = context;
        this.data = taskList;
    }

    public interface OnTaskSwipeListener {
        void onSwipeLeft(int position);
    }

    private OnTaskSwipeListener swipeListener;

    public void setOnTaskSwipeListener(OnTaskSwipeListener listener) {
        this.swipeListener = listener;
    }

    @NonNull
    @Override
    public TaskViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View itemView = inflater.inflate(R.layout.task_layout, parent, false);
        return new TaskViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull TaskViewHolder holder, int position) {
        TaskModel task = data.get(position);

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle item click here
                // For example, navigate to the ViewDescription activity with data from the clicked item
                Intent intent = new Intent(context, ViewDescription.class);
                intent.putExtra("TASK_DATA", task);
                context.startActivity(intent);
            }
        });

        // Bind other data to your ViewHolder views
        holder.bind(task.getCategory(), task.getTask(), task.getDate());
    }

    @Override
    public int getItemCount() {
        return data.size();
    }


}
