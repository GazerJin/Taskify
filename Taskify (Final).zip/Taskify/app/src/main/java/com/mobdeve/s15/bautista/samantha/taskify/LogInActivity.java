package com.mobdeve.s15.bautista.samantha.taskify;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.mobdeve.s15.bautista.samantha.taskify.database.UserDatabase;

public class LogInActivity extends AppCompatActivity {

    private EditText etUsername, etPassword;
    private UserDatabase userDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log_in);

        userDatabase = new UserDatabase(this);
        etUsername = findViewById(R.id.Username);
        etPassword = findViewById(R.id.register_password);

        Button loginButton = findViewById(R.id.login_button);
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = etUsername.getText().toString().trim();
                String password = etPassword.getText().toString().trim();

                if (userDatabase.checkUser(username, password)) {
                    // Successful login
                    Toast.makeText(LogInActivity.this, "Login successful", Toast.LENGTH_SHORT).show();

                    // Get the user ID
                    int userId = userDatabase.getUserId(username);

                    // Pass the user ID to the MainActivity
                    Intent intent = new Intent(LogInActivity.this, MainActivity.class);
                    intent.putExtra("userId", userId);
                    startActivity(intent);
                    finish(); // Close the login activity so it's not accessible after login
                } else {
                    // Invalid credentials
                    Toast.makeText(LogInActivity.this, "Invalid username or password", Toast.LENGTH_SHORT).show();
                }
            }
        });


        Button registerButton = findViewById(R.id.Register_user);
        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(LogInActivity.this, RegisterActivity.class);
                startActivity(intent);
            }
        });
    }
}
