package com.mobdeve.s15.bautista.samantha.taskify;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.LinearLayout;

import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.textfield.TextInputEditText;
import com.mobdeve.s15.bautista.samantha.taskify.model.TaskModel;

import java.util.Calendar;

public class ViewDescription extends AppCompatActivity {

    private TaskModel receivedTask;
    private int taskPosition;

    private TextView dateTextView;
    private Calendar calendar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.view_description);

        if (getIntent().hasExtra("TASK_DATA")) {
            receivedTask = (TaskModel) getIntent().getSerializableExtra("TASK_DATA");
            taskPosition = getIntent().getIntExtra("TASK_POSITION", -1);

            // TASK TITLE
            EditText taskTitleEditText = findViewById(R.id.TaskTitleUpdate);
            taskTitleEditText.setText(receivedTask.getTask());

            //DESCRIPTION
            LinearLayout linearLayout = findViewById(R.id.LinerLayoutUpdate);
            EditText descriptionEditText = linearLayout.findViewById(R.id.TextDescriptionUpdate);
            descriptionEditText.setText(receivedTask.getDescription());

            // HEAD TITLE
            TextInputEditText headTitleEditText = findViewById(R.id.HeadTitleDescription);
            headTitleEditText.setText(receivedTask.getCategory());

            // DATE
            TextView dateTextView = findViewById(R.id.SelectedDateDescription);
            dateTextView.setText(receivedTask.getDate());

        }

        dateTextView = findViewById(R.id.SelectedDateDescription);
        calendar = Calendar.getInstance();

        Button dateButton = findViewById(R.id.DateButtonDescription);
        dateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDatePickerDialog();
            }
        });
    }

    public void updateTask(View view) {
            // Get updated data from views
            EditText taskTitleEditText = findViewById(R.id.TaskTitleUpdate);
            EditText descriptionEditText = findViewById(R.id.TextDescriptionUpdate);
            TextInputEditText headTitleEditText = findViewById(R.id.HeadTitleDescription);
            TextView dateTextView = findViewById(R.id.SelectedDateDescription);

            String updatedTaskTitle = taskTitleEditText.getText().toString();
            String updatedDescription = descriptionEditText.getText().toString();
            String updatedHeadTitle = headTitleEditText.getText().toString();
            String updateDate = dateTextView.getText().toString();

            // Update task details
            receivedTask.setTask(updatedTaskTitle);
            receivedTask.setDescription(updatedDescription);
            receivedTask.setCategory(updatedHeadTitle);
            receivedTask.setDate(updateDate);

            // Prepare the updated task and its position to send back to MainActivity
            Intent resultIntent = new Intent();
            resultIntent.putExtra("UPDATED_TASK", receivedTask);
            resultIntent.putExtra("TASK_POSITION", taskPosition);
            setResult(RESULT_OK, resultIntent);
            finish();

    }

    // Method to display the DatePickerDialog
    private void showDatePickerDialog() {
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int dayOfMonth = calendar.get(Calendar.DAY_OF_MONTH);

        // Create a DatePickerDialog
        DatePickerDialog datePickerDialog = new DatePickerDialog(
                this,
                new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                        // Set the chosen date in the TextView
                        String selectedDate = getFormattedDate(monthOfYear, dayOfMonth, year);
                        dateTextView.setText(selectedDate);
                    }
                },
                year, month, dayOfMonth);

        // Show the DatePickerDialog
        datePickerDialog.show();
    }

    // Method to format the date
    private String getFormattedDate(int month, int day, int year) {
        String[] monthNames = {
                "Jan", "Feb", "Mar", "Apr", "May", "Jun",
                "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
        };

        String monthName = monthNames[month];

        // Format the date according to the desired format
        return monthName + " " + day + ", " + year;
    }
}
