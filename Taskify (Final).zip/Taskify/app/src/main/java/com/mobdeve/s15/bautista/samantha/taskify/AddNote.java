package com.mobdeve.s15.bautista.samantha.taskify;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;


import com.mobdeve.s15.bautista.samantha.taskify.database.UserDatabase;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class AddNote extends AppCompatActivity {

    private UserDatabase userDatabase;
    private int userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_note);

        userDatabase = new UserDatabase(this);

        userId = getIntent().getIntExtra("userId", -1);

        Button pickDateButton = findViewById(R.id.DateButton);
        final TextView selectedDate = findViewById(R.id.SelectedDate);

        pickDateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Calendar calendar = Calendar.getInstance();
                int day = calendar.get(Calendar.DAY_OF_MONTH);
                int month = calendar.get(Calendar.MONTH);
                int year = calendar.get(Calendar.YEAR);

                // date picker dialog
                DatePickerDialog datePickerDialog = new DatePickerDialog(
                        AddNote.this,
                        new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                                // this method is called when a date is selected
                                // you can use the selected date here
                                // format the date as a word
                                SimpleDateFormat dateFormat = new SimpleDateFormat("MMM d, yyyy", Locale.US);
                                Date date = new Date(year - 1900, month, dayOfMonth);
                                String formattedDate = dateFormat.format(date);
                                selectedDate.setText(formattedDate);
                            }
                        },
                        year,
                        month,
                        day
                );
                datePickerDialog.show();
            }
        });

        Button saveButton = findViewById(R.id.SaveTask);
        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveTaskToDatabase();
            }
        });
    }

    private void saveTaskToDatabase() {
        EditText taskNameEditText = findViewById(R.id.TaskNameIn);
        EditText taskDescriptionEditText = findViewById(R.id.TaskDescription);
        EditText headTitleEditText = findViewById(R.id.HeadTitleNameIN);
        TextView selectedDateTextView = findViewById(R.id.SelectedDate);

        String taskName = taskNameEditText.getText().toString();
        String taskDescription = taskDescriptionEditText.getText().toString();
        String headTitle = headTitleEditText.getText().toString();
        String selectedDate = selectedDateTextView.getText().toString();

        // Assuming user ID is 1 for demonstration purposes
        userDatabase.addTask(userId, selectedDate, headTitle, taskName, taskDescription);

        Toast.makeText(this, "Task saved successfully!", Toast.LENGTH_SHORT).show();

        Intent intent = new Intent(AddNote.this, MainActivity.class);
        intent.putExtra("userId", userId); // Sending the userId instead of the flag
        startActivity(intent);
        finish();
    }
}
