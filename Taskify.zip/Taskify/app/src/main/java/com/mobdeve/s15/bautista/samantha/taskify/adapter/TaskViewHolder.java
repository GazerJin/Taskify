package com.mobdeve.s15.bautista.samantha.taskify.adapter;

import android.view.View;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.mobdeve.s15.bautista.samantha.taskify.R;

public class TaskViewHolder extends RecyclerView.ViewHolder {
    private TextView tvHeadTitle;
    protected TextView tvTaskTitle;
    private TextView tvDate;
    private TextView tvDescription;

    public TaskViewHolder(@NonNull View itemView) {
        super(itemView);
        tvHeadTitle = itemView.findViewById(R.id.HeadTitle);
        tvTaskTitle = itemView.findViewById(R.id.TaskTitle);
        tvDate = itemView.findViewById(R.id.Date);
        tvDescription = itemView.findViewById(R.id.TaskDescription);
    }

    public void bind(String title, String task, String date) {
        tvHeadTitle.setText(title);
        tvTaskTitle.setText(task);
        tvDate.setText(date);
    }


}


