package com.mobdeve.s15.bautista.samantha.taskify;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.ItemTouchHelper;



import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageView;
import android.view.MenuItem;
import android.widget.PopupMenu;

import com.mobdeve.s15.bautista.samantha.taskify.adapter.TaskAdapter;
import com.mobdeve.s15.bautista.samantha.taskify.database.UserDatabase;
import com.mobdeve.s15.bautista.samantha.taskify.model.TaskModel;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private TaskAdapter taskAdapter;
    private List<TaskModel> taskList;
    private static final int REQUEST_CODE_UPDATE_TASK = 100;
    private UserDatabase userDatabase;
    private int UserId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        recyclerView = findViewById(R.id.Recycler);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        UserId = getIntent().getIntExtra("userId", -1);


        userDatabase = new UserDatabase(this);
        taskList = userDatabase.getTasksForUser(UserId); // Fetch tasks for user ID 1 (admin) // change later

        taskAdapter = new TaskAdapter(this, taskList);
        recyclerView.setAdapter(taskAdapter);


        // Add Task button functionality
        findViewById(R.id.AddTasks).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, AddNote.class);
                intent.putExtra("userId", UserId);
                startActivity(intent);
            }
        });

        recyclerView.addOnItemTouchListener(new RecyclerView.OnItemTouchListener() {
            @Override
            public boolean onInterceptTouchEvent(@NonNull RecyclerView rv, @NonNull MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_UP:
                        View child = rv.findChildViewUnder(e.getX(), e.getY());
                        int position = rv.getChildAdapterPosition(child);

                        if (child != null && position != RecyclerView.NO_POSITION) {
                            TaskModel clickedTask = taskList.get(position);

                            Intent intent = new Intent(MainActivity.this, ViewDescription.class);
                            intent.putExtra("TASK_DATA", clickedTask);
                            intent.putExtra("TASK_POSITION", position); // Pass the position of the clicked task
                            startActivityForResult(intent, REQUEST_CODE_UPDATE_TASK);
                            return true; // Consume this touch event
                        }
                        break;
                }
                return false;
            }

            @Override
            public void onTouchEvent(@NonNull RecyclerView rv, @NonNull MotionEvent e) {}

            @Override
            public void onRequestDisallowInterceptTouchEvent(boolean disallowIntercept) {}
        });

        ItemTouchHelper.SimpleCallback simpleItemTouchCallback =
                new ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.LEFT | ItemTouchHelper.RIGHT) {

                    @Override
                    public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder target) {
                        // Placeholder for onMove method
                        return false;
                    }

                    @Override
                    public void onSwiped(RecyclerView.ViewHolder viewHolder, int swipeDir) {
                        // Get the position of the swiped item
                        final int position = viewHolder.getAdapterPosition();

                        // Create and show the confirmation dialog
                        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                        builder.setMessage("Are you sure you want to delete this task?")
                                .setCancelable(false)
                                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        // User clicked "Yes" button, delete the task
                                        userDatabase.deleteTask(taskList.get(position).getId());

                                        // Remove the task from the list
                                        taskList.remove(position);

                                        // Notify the adapter of the removal
                                        taskAdapter.notifyItemRemoved(position);
                                    }
                                })
                                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        // User clicked "No" button, dismiss the dialog and reset the item position
                                        taskAdapter.notifyItemChanged(position);
                                        dialog.dismiss();
                                    }
                                });
                        AlertDialog alert = builder.create();
                        alert.show();
                    }

                };

        // Attach the ItemTouchHelper to the RecyclerView
        ItemTouchHelper itemTouchHelper = new ItemTouchHelper(simpleItemTouchCallback);
        itemTouchHelper.attachToRecyclerView(recyclerView);

        ImageView menubar = findViewById(R.id.MenuBar);
        menubar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Create a PopupMenu
                PopupMenu popupMenu = new PopupMenu(MainActivity.this, menubar);

                // Inflate the menu
                popupMenu.getMenuInflater().inflate(R.menu.menu_main, popupMenu.getMenu());

                // Set a click listener for the menu items
                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem item) {
                        if (item.getItemId() == R.id.action_logout) {
                            // Handle logout
                            logout();
                            return true;
                        } else {
                            return false;
                        }
                    }
                });


                // Show the popup menu
                popupMenu.show();
            }
        });

    }




    private void startViewDescriptionActivityForResult(TaskModel task) {
        Intent intent = new Intent(MainActivity.this, ViewDescription.class);
        intent.putExtra("TASK_DATA", task);
        startActivityForResult(intent, REQUEST_CODE_UPDATE_TASK);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_CODE_UPDATE_TASK && resultCode == RESULT_OK && data != null) {
            TaskModel updatedTask = (TaskModel) data.getSerializableExtra("UPDATED_TASK");
            int taskPosition = data.getIntExtra("TASK_POSITION", -1);

            if (taskPosition != -1 && updatedTask != null) {

                // Update the task in the list at the given position
                taskList.set(taskPosition, updatedTask);
                // Notify the adapter of the data change
                taskAdapter.notifyItemChanged(taskPosition);
                // Update the task in the database
                UserDatabase userDatabase = new UserDatabase(this);
                userDatabase.updateTask(updatedTask);
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();

        int updatedUserId = getIntent().getIntExtra("userId", -1);

        if (updatedUserId != -1) {
            // Refresh the taskList when new data is added or updated
            taskList.clear();
            taskList.addAll(userDatabase.getTasksForUser(updatedUserId)); // Refresh the task list
            taskAdapter.notifyDataSetChanged(); // Notify adapter about the change

            // Reset the flag to avoid refreshing the list on every resume
            getIntent().removeExtra("userId");
        }
    }

    private void logout() {
        Intent intent = new Intent(MainActivity.this, LogInActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }


}


