package com.mobdeve.s15.bautista.samantha.taskify.database;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.mobdeve.s15.bautista.samantha.taskify.model.TaskModel;

import java.util.ArrayList;
import java.util.List;

public class UserDatabase extends SQLiteOpenHelper {

    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "UserDatabase";
    private static final String USER_INFO_TABLE = "users";
    private static final String TASKS_TABLE = "tasks";

    private static final String USER_ID = "id";
    private static final String USER_USERNAME = "username";
    private static final String USER_PASSWORD = "password";

    private static final String TASK_ID = "id";
    private static final String TASK_USER_ID = "user_id";
    private static final String TASK_DATE = "date";
    private static final String TASK_HEAD_TITLE = "head_title";
    private static final String TASK_TITLE = "task_title";
    private static final String TASK_DESCRIPTION = "description";

    public UserDatabase(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        addDummyData();
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_USERS_TABLE = "CREATE TABLE " + USER_INFO_TABLE + "("
                + USER_ID + " INTEGER PRIMARY KEY,"
                + USER_USERNAME + " TEXT,"
                + USER_PASSWORD + " TEXT"
                + ")";
        db.execSQL(CREATE_USERS_TABLE);

        String CREATE_TASKS_TABLE = "CREATE TABLE " + TASKS_TABLE + "("
                + TASK_ID + " INTEGER PRIMARY KEY,"
                + TASK_USER_ID + " INTEGER,"
                + TASK_DATE + " TEXT,"
                + TASK_HEAD_TITLE + " TEXT,"
                + TASK_TITLE + " TEXT,"
                + TASK_DESCRIPTION + " TEXT,"
                + "FOREIGN KEY(" + TASK_USER_ID + ") REFERENCES " + USER_INFO_TABLE + "(" + USER_ID + ")"
                + ")";
        try {
            db.execSQL(CREATE_TASKS_TABLE);
            Log.d("UserDatabase", "Tasks table created successfully");
        } catch (SQLException e) {
            Log.e("UserDatabase", "Error creating tasks table: " + e.getMessage());
        }
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TASKS_TABLE);
        db.execSQL("DROP TABLE IF EXISTS " + USER_INFO_TABLE);
        onCreate(db);
    }

    public void addUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(USER_USERNAME, username);
        values.put(USER_PASSWORD, password);

        db.insert(USER_INFO_TABLE, null, values);
        db.close();
    }

    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] columns = {USER_ID};
        String selection = USER_USERNAME + " = ?" + " AND " + USER_PASSWORD + " = ?";
        String[] selectionArgs = {username, password};

        Cursor cursor = db.query(USER_INFO_TABLE, columns, selection, selectionArgs,
                null, null, null);
        int count = cursor.getCount();
        cursor.close();
        db.close();

        return count > 0;
    }

    public boolean isUsernameExists(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] columns = {USER_ID};
        String selection = USER_USERNAME + " = ?";
        String[] selectionArgs = {username};

        Cursor cursor = db.query(USER_INFO_TABLE, columns, selection, selectionArgs,
                null, null, null);
        int count = cursor.getCount();
        cursor.close();
        db.close();

        return count > 0;
    }

    public boolean userHasTasks(int userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] columns = {USER_ID};
        String selection = USER_ID + " = ?";
        String[] selectionArgs = {String.valueOf(userId)};

        Cursor cursor = db.query("Tasks", columns, selection, selectionArgs,
                null, null, null);
        int count = cursor.getCount();
        cursor.close();
        db.close();

        return count > 0;
    }



    public void addTask(int userId, String date, String headTitle, String taskTitle, String description) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(TASK_USER_ID, userId);
        values.put(TASK_DATE, date);
        values.put(TASK_HEAD_TITLE, headTitle);
        values.put(TASK_TITLE, taskTitle);
        values.put(TASK_DESCRIPTION, description);

        db.insert(TASKS_TABLE, null, values);
        db.close();

    }

    public List<TaskModel> getTasksForUser(int userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        List<TaskModel> taskList = new ArrayList<>();

        String[] columns = {TASK_ID, TASK_DATE, TASK_HEAD_TITLE, TASK_TITLE, TASK_DESCRIPTION};
        String selection = TASK_USER_ID + " = ?";
        String[] selectionArgs = {String.valueOf(userId)};

        Cursor cursor = db.query(TASKS_TABLE, columns, selection, selectionArgs, null, null, null);

        int taskIdIndex = cursor.getColumnIndex(TASK_ID);
        int dateIndex = cursor.getColumnIndex(TASK_DATE);
        int headTitleIndex = cursor.getColumnIndex(TASK_HEAD_TITLE);
        int titleIndex = cursor.getColumnIndex(TASK_TITLE);
        int descriptionIndex = cursor.getColumnIndex(TASK_DESCRIPTION);

        while (cursor.moveToNext()) {
            int taskId = cursor.getInt(taskIdIndex);
            String date = cursor.getString(dateIndex);
            String headTitle = cursor.getString(headTitleIndex);
            String title = cursor.getString(titleIndex);
            String description = cursor.getString(descriptionIndex);

            TaskModel task = new TaskModel(taskId, headTitle, title, date, description);
            taskList.add(task);
        }

        cursor.close();
        db.close();

        return taskList;
    }

    public void updateTask(TaskModel task) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(TASK_DATE, task.getDate());
        values.put(TASK_HEAD_TITLE, task.getCategory());
        values.put(TASK_TITLE, task.getTask());
        values.put(TASK_DESCRIPTION, task.getDescription());

        db.update(TASKS_TABLE, values, TASK_ID + " = ?", new String[]{String.valueOf(task.getId())});
        db.close();
    }

    @SuppressLint("Range")
    public int getUserId(String username) {
        SQLiteDatabase db = this.getReadableDatabase();

        // Select the user ID where the username is the given username
        Cursor cursor = db.rawQuery("SELECT * FROM users WHERE username = ?", new String[]{username});

        // Log the column names
        for (int i = 0; i < cursor.getColumnCount(); i++) {
            Log.d("UserDatabase", "Column " + i + ": " + cursor.getColumnName(i));
        }

        int userId = -1;
        if (cursor.moveToFirst()) {
            userId = cursor.getInt(cursor.getColumnIndex("id"));
        }

        cursor.close();
        return userId;
    }

    public void deleteTask(int taskId) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TASKS_TABLE, TASK_ID + "=?", new String[]{String.valueOf(taskId)});
        db.close();
    }


    private void addDummyData() {
        if (!isUsernameExists("admin")) {
            addUser("admin", "12345");
        }

        // Check if the user with ID 1 (admin) has no tasks
        if (!userHasTasks(1)) {
            // Add tasks for user with ID 1 (admin)
            addTask(1, "Nov 22, 2023", "MOBDEVE", "Quizzes", "Green");
            addTask(1, "Nov 23, 2023", "People", "Kill", "Yellow");
            addTask(1, "Nov 23, 2023", "People", "Kill", "skill");
        }
    }
}
